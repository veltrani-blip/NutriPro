# NutriPro

SaaS multi-tenant para nutricionistas e clínicas, com agenda, prontuário versionado, avaliação antropométrica, planos alimentares, portal do paciente, documentos PDF, financeiro, equipe, relatórios e administração da plataforma.

O produto usa dados persistidos. Uma organização nova começa vazia, sem pacientes, vendas, depoimentos ou indicadores preenchidos artificialmente.

## Stack efetiva

- Next.js 16.3.0, React 19.2.8 e TypeScript 5.9.3 em modo estrito;
- Tailwind CSS 4;
- Supabase Auth, PostgreSQL 17, Storage privado e Row Level Security;
- Zod 4 para validação;
- Vitest 4 e Playwright 1.62;
- `pdf-lib` para PDFs imutáveis;
- banco PostgreSQL portátil para verificar migrations quando Docker não está disponível.

As versões são fixadas em `package.json` e `package-lock.json`.

## Arquitetura resumida

```text
Browser
  -> Next.js App Router / Server Actions
     -> Supabase Auth SSR
     -> PostgreSQL + RLS + funções transacionais
     -> Storage privado + URLs assinadas
     -> gateway opcional por contrato HTTP + webhook HMAC
```

A interface não é a autoridade de acesso. RLS, permissões e constraints do PostgreSQL protegem todas as linhas tenant-scoped. Leia `docs/ARCHITECTURE.md` e `docs/SECURITY.md`.

## Requisitos

- Node.js 22 ou superior;
- npm 11 ou compatível com o lockfile;
- um projeto Supabase para uso remoto;
- Docker apenas para o ambiente Supabase local completo;
- sem Docker, `npm run db:verify:portable` executa as migrations duas vezes em PostgreSQL 17 temporário.

## Instalação

```powershell
npm ci
Copy-Item .env.example .env.local
```

Preencha em `.env.local`:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://SEU_PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_SUA_CHAVE
NEXT_PUBLIC_APP_URL=http://localhost:3000
APP_NAME=NutriPro
```

As variáveis server-only do gateway são opcionais e ficam descritas em `docs/EXTERNAL_CONFIG.md`.

## Supabase local

Com Docker ativo:

```powershell
npx supabase start
npx supabase db reset
npm run dev
```

URLs, portas, política de senha, confirmação de e-mail, rate limits e TOTP local estão em `supabase/config.toml`. Nenhum seed de produção é aplicado.

Para encerrar:

```powershell
npx supabase stop
```

## Supabase remoto

1. Crie um projeto no painel Supabase.
2. Autentique e vincule o checkout:

```powershell
npx supabase login
npx supabase link --project-ref SEU_PROJECT_REF
npx supabase db push
```

3. Em Authentication > URL Configuration, defina o Site URL e permita `https://SEU_DOMINIO/auth/callback`.
4. Ative confirmação de e-mail, troca segura de senha e TOTP.
5. Configure SMTP próprio antes de tráfego real.
6. Confirme que todos os buckets criados pelas migrations permanecem privados.
7. Execute Security Advisor e Performance Advisor e trate achados antes da abertura pública.

As migrations são aplicadas em ordem lexical a partir de `supabase/migrations/`. Não edite migrations já aplicadas em produção; adicione uma nova migration.

## Storage

As migrations criam buckets privados para avatares, logos, assinaturas, pacientes, evolução, exames, documentos e receitas. Os caminhos começam por `organization_id`; políticas validam organização, ownership e vínculos do portal.

Uploads passam por limite de tamanho, MIME permitido, assinatura mágica do conteúdo e nome aleatório. Downloads clínicos usam URLs assinadas curtas ou rotas autenticadas.

## Execução

```powershell
npm run dev
```

Acesse `http://localhost:3000`. O primeiro usuário confirma o e-mail, entra, conclui o onboarding e cria a organização de forma transacional.

Para executar o build:

```powershell
npm run build
npm start
```

O health check está em `/api/health` e não expõe secrets nem estado clínico.

## Testes e qualidade

```powershell
npm run verify:text
npm run lint
npm run typecheck
npm test
npm run db:verify:portable
npm run build
npm run test:e2e
```

`npm run db:verify:portable` valida duas instalações limpas das migrations, RLS, RBAC, IDOR cross-tenant, storage, convites, portal, transações clínicas/financeiras, webhook idempotente e concorrência de agenda.

`npm run test:e2e` inicia o Next.js e executa o smoke público. Fluxos autenticados contra o ambiente remoto exigem as contas de teste e credenciais do proprietário descritas em `docs/EXTERNAL_CONFIG.md`.

## Deploy

O destino recomendado é Vercel + Supabase gerenciado:

1. aplique migrations no projeto remoto;
2. configure as variáveis públicas no projeto Vercel;
3. configure variáveis server-only somente se o gateway online for ativado;
4. execute `npm run build` no pipeline;
5. publique;
6. atualize Site URL e Redirect URLs no Supabase;
7. valide cadastro, confirmação, recuperação, login, MFA, onboarding e um fluxo com cada papel.

Não defina `SUPABASE_SERVICE_ROLE_KEY` como variável pública e nunca use o prefixo `NEXT_PUBLIC_` nela.

## Backup e restauração

- habilite backups automáticos e PITR conforme o plano Supabase;
- teste restauração em um projeto separado;
- preserve migrations, configuração de Auth e inventário de buckets;
- para exportação lógica administrativa, use `npx supabase db dump` ou `pg_dump` com credencial temporária e destino criptografado;
- restaure primeiro schema, depois dados, depois valide RLS, funções e objetos de Storage;
- não faça restauração destrutiva sobre produção sem janela, backup confirmado e plano de retorno.

## Segurança e LGPD

Informação clínica é tratada como dado pessoal sensível. O sistema aplica menor privilégio, segregação tenant, URLs privadas, trilha de auditoria sem secrets, minimização, exportação autorizada e solicitações de privacidade sujeitas a análise humana e retenção configurável.

A documentação não substitui revisão jurídica brasileira. Políticas de retenção, termos, consentimentos e bases legais devem ser aprovados pelo responsável jurídico/controlador.

## Integrações

- e-mail de autenticação: SMTP do Supabase;
- pagamento online: contrato HTTP documentado, cobrança idempotente e webhook HMAC;
- WhatsApp, teleconsulta, monitoramento e IA: ficam desativados enquanto não houver provedor e credencial real;
- financeiro manual, PDFs, portal e módulos clínicos não dependem dessas integrações opcionais.

Veja todas as variáveis, locais de configuração e testes em `docs/EXTERNAL_CONFIG.md`.

## Estrutura

- `src/app`: rotas, páginas, handlers e Server Actions;
- `src/lib`: autenticação, cálculos, PDFs, Supabase, storage e adapters;
- `src/components`: interface compartilhada;
- `supabase/migrations`: schema, RLS, funções e constraints;
- `tests`: testes unitários e de contrato;
- `e2e`: smoke tests em navegador;
- `scripts`: validação textual e banco portátil;
- `docs`: arquitetura, segurança, módulos e configuração externa;
- `FINAL_REPORT.md`: evidências executadas da entrega.

## Diagnóstico rápido

- erro de URL/chave Supabase: confirme `.env.local` e reinicie o Next.js;
- redirecionamento recusado: revise Site URL e Redirect URLs no Auth;
- acesso negado: confirme organização, papel, override e policy RLS; não contorne com service role;
- upload recusado: confira bucket, MIME, assinatura do arquivo, tamanho e prefixo do caminho;
- migration local sem Docker: use `npm run db:verify:portable`;
- cobrança online indisponível: mantenha o financeiro manual e siga `docs/EXTERNAL_CONFIG.md`;
- recibo recusado: o pagamento deve estar quitado, ter paciente e meio de pagamento válido.
